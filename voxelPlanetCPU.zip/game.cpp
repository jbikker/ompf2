#include "precomp.h" 

// settings
#define EPSILON			0.00002f
#define GRIDSIZE		64						// blocks per axis per sextant
#define BLOCKSIZE		32						// number of voxels in a block, per axis
#define BRICKSIZE		4						// number of voxels in a brick, per axis
#define SHELL			0.02f					// height of a block shell
#define SHELLS			4						// number of shells
#define THREADS			24						// threads to use for the renderer

// derived and internal
#define MIN_DIM(x,y,z)	(((x)<(y))?(((x)<(z))?0:2):(((y)<(z))?1:2))
#define BRICKCOUNT		(BLOCKSIZE/BRICKSIZE)	// number of bricks in a block, per axis
#define TILESIZE		32						// width and height (in pixels) of a work unit
#define BRICKMASK		(BRICKSIZE - 1)
#define BPOSMASK		(BLOCKSIZE - BRICKSIZE)
#define BRICKSIZE2		(BRICKSIZE * BRICKSIZE)
#define BRICKCOUNT2		(BRICKCOUNT * BRICKCOUNT)
#define BLOCKSIZE2		(BLOCKSIZE * BLOCKSIZE)
#define INV2PI			(2.0f/PI)
#define ATAN2( x, y )	atanf(x/y)
// #define ATAN2( x, y )	((x) * (y)) / ((y) * (y) + 0.28125f * (x) * (x))

vec3 uplane[6][GRIDSIZE + 1];					// planes defining the grid for each sextant: u
vec3 vplane[6][GRIDSIZE + 1];					// planes defining the grid for each sextant: v

const float r2s[5] = { // squared radii of the sphere shells
	1, (1 - SHELL) * (1 - SHELL), (1 - 2 * SHELL) * (1 - 2 * SHELL), 
	(1 - 3 * SHELL) * (1 - 3 * SHELL), (1 - 4 * SHELL) * (1 - 4 * SHELL) 
};

const float hb[5] = { 1.0f - 1.0f * SHELL, 1.0f - 2.0f * SHELL, 
	1.0f - 3.0f * SHELL, 1.0f - 4.0f * SHELL, 1.0f - 5.0f * SHELL };

const vec3 v2[6] = { { 0, 0, -1 }, { 0, 0, 1 }, { 1, 0, 0 }, 
	{ 1, 0, 0 }, { 1, 0, 0 }, { -1, 0, 0 } };

const int neigh[6][4] = { // neighbouring sextants in four directions
	{ 5, 4, 2, 3 }, { 4, 5, 2, 3 }, { 0, 1, 5, 4 }, { 0, 1, 4, 5 }, { 0, 1, 2, 3 }, { 1, 0, 2, 3 } };

const int back[6][6] = { // if we came from X then it's in this direction
	{ 9, 9, 2, 3, 1, 0 }, { 9, 9, 2, 3, 0, 1 }, { 0, 1, 9, 9, 3, 2 }, 
	{ 0, 1, 9, 9, 2, 3 }, { 0, 1, 2, 3, 9, 9 }, { 1, 0, 2, 3, 9, 9 }
};

const static vec3 M[6] = { 
	vec3( -1, 0, 0 ), vec3( 1, 0,  0 ), vec3( 0, -1, 0 ), 
	vec3(  0, 1, 0 ), vec3( 0, 0, -1 ), vec3( 0,  0, 1 ),
};

int* vdata;		// raw voxel data, BLOCKSIZE ^ 3
int* brick;		// brickdata, BRICKSIZE ^ 3 * BRICKCOUNT ^ 3 = BLOCKSIZE ^ 3
int* offs;		// brick offsets, BRICKCOUNT ^ 3
int* grid[6];	// block indices; GRIDSIZE * GRIDSIZE * SHELLS per sextant

// intersect ray with sphere
float sphereint( const vec3& O, const vec3& D, const float r2 )
{
	const float tca = dot( -O, D );
	const float d2 = dot( O, O ) - tca * tca;
	if (d2 > r2) return 1e34f;
	const float thc = sqrtf( r2 - d2 ), t0 = tca - thc, t1 = tca + thc;
	if (t0 > 0) return t0; else if (t1 > 0) return t1; else return 1e34f;
}

// intersect ray with plane through origin, return 1e34f for no hit
float planeint( const vec3& O, const vec3& D, const vec3& N )
{
	const float d = -dot( D, N );
	if (d == 0) return 1e34f;
	const float t = dot( O, N ) / d;
	return t > 0 ? t : 1e34f;
}

// determine sphere sextant based on 3D position
int sextant( const vec3& I )
{
	const float v[3] = { I.x, I.y, I.z };
	const int d1 = (fabs( v[0] ) > fabs( v[1] )) ? 0 : 2;
	const int d2 = fabs( v[2] ) > fabs( v[d1 >> 1] ) ? 4 : d1;
	return d2 + (v[d2 >> 1] > 0 ? 1 : 0);
}

// determine sphere shell for 3D position P
int getshell( const vec3 P )
{
	return (int)((1.0f - P.length()) * (1.0f / SHELL));
}

// get cube space coordinates based on position and sextant
void getuv( const vec3& P, const int sext, int& iu, int& iv )
{
	// "Comparison of Spherical Cube Map Projections used in Planet-sized Terrain Rendering", ASC method (4.2)
	vec3 I = normalize( P );
	const float c[12] = { I.z, I.x, I.y, 0, I.x, I.y, I.z, 0, I.x, I.z, I.y, 0 };
	static const float su[6] = { 1, 1, -1, 1, -1, -1 }, sv[6] = { -1, 1, 1, 1, -1, 1 };
	const float* d = c + (sext >> 1) * 4;
	iu = clamp( (int)(INV2PI * GRIDSIZE * ATAN2( d[0], d[1] ) * su[sext] + GRIDSIZE / 2), 0, GRIDSIZE - 1 );
	iv = clamp( (int)(INV2PI * GRIDSIZE * ATAN2( d[2], d[1] ) * sv[sext] + GRIDSIZE / 2), 0, GRIDSIZE - 1 );
}

// transform normal into integer 32-bit ARGB color
unsigned int normalcol( const vec3& I, const vec3& N, int sext )
{
	const vec3 Nb = normalize( I );
	const vec3 Bb = normalize( cross( Nb, v2[sext] ) );
	const vec3 Tb = cross( Bb, Nb );
	const vec3 lN = N.x * Tb + N.y * Bb + N.z * Nb;
	return ((int)((lN.x + 1) * 127.0f) << 16) + ((int)((lN.y + 1) * 127.0f) << 8) + (int)((lN.z + 1) * 127.0f);
}

// two-level grid traversal bitfield access
#define OFFS_X		((bits >> 5) & 1)			// extract grid plane offset over x (0 or 1)
#define OFFS_Y		((bits >> 13) & 1)			// extract grid plane offset over y (0 or 1)
#define OFFS_Z		(bits >> 21)				// extract grid plane offset over z (0 or 1)
#define DIR_X		((bits & 3) - 1)			// ray dir over x (-1 or 1)
#define DIR_Y		(((bits >> 8) & 3) - 1)		// ray dir over y (-1 or 1)
#define DIR_Z		(((bits >> 16) & 3) - 1)	// ray dir over z (-1 or 1)
#define DIR_M(m)	(((bits >> m) & 3) - 1)		// ray dir for axis m (-1 or 1)
#define LAST(m)		(bits >> (m + 2)) & 7		// last touched cube side (0..6)

// two-level grid traversal
bool traceblock( const vec3& A, const vec3& B, int last, float& dist, vec3& N )
{
	const vec3 V = B - A, rV( 1.0f / V.x, 1.0f / V.y, 1.0f / V.z );
	uint pos[3] = { clamp( (uint)A.x, 0u, BLOCKSIZE - 1u ), clamp( (uint)A.y, 0u, BLOCKSIZE - 1u ), clamp( (uint)A.z, 0u, BLOCKSIZE - 1u ) };
	const int bits = (V.x > 0 ? 34 : 4) + (V.y > 0 ? 10752 : 3072) + (V.z > 0 ? 3276800 : 1310720); // magic
	float tmax[3] = { ((pos[0] & BPOSMASK) + BRICKSIZE * OFFS_X - A.x) * rV.x,
					  ((pos[1] & BPOSMASK) + BRICKSIZE * OFFS_Y - A.y) * rV.y,
					  ((pos[2] & BPOSMASK) + BRICKSIZE * OFFS_Z - A.z) * rV.z }, t = 0;
	const float td[3] = { DIR_X * rV.x, DIR_Y * rV.y, DIR_Z * rV.z }; // remove?
	while (1)
	{
		const int o = offs[pos[0] / BRICKSIZE + (pos[1] / BRICKSIZE) * BRICKCOUNT + (pos[2] / BRICKSIZE) * BRICKCOUNT2];
		if (o > -1)
		{
			float d = t;
			const vec3 I = A + V * t;
			const int bx = pos[0] & BPOSMASK, by = pos[1] & BPOSMASK, bz = pos[2] & BPOSMASK;
			int p = clamp( (int)I.x, bx, bx + BRICKSIZE - 1 ) + (clamp( (int)I.y, by, by + BRICKMASK ) << 8) + (clamp( (int)I.z, bz, bz + BRICKMASK ) << 16);
			float tmax[3] = { ((p & 255) + OFFS_X - A.x) * rV.x, (((p >> 8) & 255) + OFFS_Y - A.y) * rV.y, ((p >> 16) + OFFS_Z - A.z) * rV.z };
			while (1)
			{
				if (brick[o + (p & BRICKMASK) + ((p >> 8) & BRICKMASK) * BRICKSIZE + ((p >> 16) & BRICKMASK) * BRICKSIZE2] == 1) 
				{ 
					N = M[last]; 
					dist = d; 
					return true; 
				}
				const unsigned int m = MIN_DIM( tmax[0], tmax[1], tmax[2] ), m8 = 8 * m, n = ((p >> m8) & BRICKMASK) + DIR_M(m8);
				p += DIR_M(m8) << m8, d = tmax[m], tmax[m] += td[m], last = LAST(m8);
				if (n >= BRICKSIZE) break;
			}
		}
		const int m = MIN_DIM( tmax[0], tmax[1], tmax[2] );
		pos[m] += DIR_M(m*8) * BRICKSIZE, t = tmax[m], tmax[m] += td[m] * BRICKSIZE, last = LAST(m * 8);
		if (pos[m] >= BLOCKSIZE) return false;
	}
	return false;
}

int blockidx( const int sext, const int u, const int v, const int l )
{
	return grid[sext][u + v * GRIDSIZE + l * GRIDSIZE * GRIDSIZE];
}

// sphere grid traversal
unsigned int trace( const vec3& O, const vec3& D )
{
	vec3 P = O;
	int sext, nsext, shell, step = 0, valid, last = 0;
	// planet hull has a radius of 1 unit; see if we started inside the hull
	if (dot( O, O ) > r2s[0])
	{
		// advance to hull
		const float t = sphereint( O, D, r2s[0] );
		if (t == 1e34f) return 0; // missed hull
		P += (t + EPSILON) * D;
		last = 5;
	}
	// find initial sextant, shell and position
	sext = nsext = sextant( P ), shell = getshell( P );
	if (shell < 0 || shell >= SHELLS) return 0; // apparently this happens
	// loop until we leave the sextant
	while (1)
	{
		// where did we come from?
		valid = 63;
		if (nsext != sext) valid -= 1 << back[nsext][sext];
		// determine initial sext/shell/u/v
		sext = nsext;
		if (shell < 0) return 0;
		if (shell >= SHELLS) return 0x333388;
		int iu, iv;
		getuv( P, sext, iu, iv );
		// loop over blocks
		while (1)
		{
			if (++step > 150) return 0xffffff;
			const float tu0 = valid & 1 ? planeint( P, D, uplane[sext][iu + 0] ) : 1e34f;
			const float tu1 = valid & 2 ? planeint( P, D, uplane[sext][iu + 1] ) : 1e34f;
			const float tv0 = valid & 4 ? planeint( P, D, vplane[sext][iv + 0] ) : 1e34f;
			const float tv1 = valid & 8 ? planeint( P, D, vplane[sext][iv + 1] ) : 1e34f;
			const float tw0 = valid & 32 ? sphereint( P, D, r2s[shell] ) : 1e34f;
			const float tw1 = valid & 16 ? sphereint( P, D, r2s[shell + 1] ) : 1e34f; 
			const float t = min( min( min( tu0, tu1 ), min( tv0, tv1 ) ), min( tw0, tw1 ) );
			if (t == 1e34f) return 0;
			const vec3 E = P + t * D;
			// trace block contents
			int b = blockidx( sext, iu, iv, shell );
			if (b)
			{
				const float du0 = dot( P, uplane[sext][iu] ), dv0 =  dot( P, vplane[sext][iv] );
				const float uA = du0 / (du0 - dot( P, uplane[sext][iu + 1] ));
				const float vA = dv0 / (dv0 - dot( P, vplane[sext][iv + 1] ));
				const float du2 =  dot( E, uplane[sext][iu] ), dv2 =  dot( E, vplane[sext][iv] );
				const float uB = du2 / (du2 - dot( E, uplane[sext][iu + 1] ));
				const float vB = dv2 / (dv2 - dot( E, vplane[sext][iv + 1] ));
				const float wA = (P.length() - hb[shell]) / SHELL;
				const float wB = (E.length() - hb[shell]) / SHELL;
				const vec3 A = (float)BLOCKSIZE * vec3( uA, vA, wA );
				const vec3 B = (float)BLOCKSIZE * vec3( uB, vB, wB );
				float dist;
				vec3 N;
				if (traceblock( A, B, last, dist, N ))
				{
					// transform block normal to sphere space
					vec3 I = P + dist * (1.0f / BLOCKSIZE) * D;
					return normalcol( I, N, sext );
				}
			}
			// advance
			bool next = false;
			valid = 63;
				 if (t == tu0) valid -= 2, nsext = neigh[sext][0], last = 0, next = (--iu < 0);
			else if (t == tu1) valid -= 1, nsext = neigh[sext][1], last = 1, next = (++iu == GRIDSIZE);
			else if (t == tv0) valid -= 8, nsext = neigh[sext][2], last = 2, next = (--iv < 0);
			else if (t == tv1) valid -= 4, nsext = neigh[sext][3], last = 3, next = (++iv == GRIDSIZE);
			else if (t == tw0) { valid -= 16, last = 5; if (--shell < 0) return 0; }
			else if (t == tw1) 
			{ 
				valid -= 32, last = 4; 
				if (++shell >= SHELLS) return normalcol( P + t * D, vec3( 0, 0, 1 ), sext ); 
			}
			P = E;
			if (next) break;
		}
	}
	return 0;
}

// initialize application
void Game::Init()
{
	const float step = 0.5f * PI / GRIDSIZE;
	for( int i = 0; i < (GRIDSIZE + 1); i++ )
	{
		const float angle = 0.25f * PI - (float)i * step, u = sinf( angle ), v = cosf( angle );
		uplane[0][i] = vec3( -u, 0, -v ), vplane[0][i] = vec3( -u, v, 0 );	// x-
		uplane[1][i] = vec3( u, 0, v ), vplane[1][i] = vec3( u, v, 0 );		// x+
		uplane[2][i] = vec3( v, -u, 0 ), vplane[2][i] = vec3( 0, -u, -v );	// y-
		uplane[3][i] = vec3( v, u, 0 ), vplane[3][i] = vec3( 0, u, v );		// y+
		uplane[4][i] = vec3( v, 0, -u ), vplane[4][i] = vec3( 0, v, -u );	// z-
		uplane[5][i] = vec3( -v, 0, u ), vplane[5][i] = vec3( 0, v, u );	// z+
	}
	vdata = new int[BLOCKSIZE * BLOCKSIZE * BLOCKSIZE];
	for( int z = 0; z < BLOCKSIZE; z++ ) for( int y = 0; y < BLOCKSIZE; y++ ) for( int x = 0; x < BLOCKSIZE; x++ )
	{
		int v = (x > 3 && y > 3 && z > 3 && x < 30 && y < 30 && z < 30) ? 1 : 0;
		vdata[x + y * BLOCKSIZE + z * BLOCKSIZE2] = v;
	}
	// convert to bricks
	brick = new int[BLOCKSIZE * BLOCKSIZE2], offs = new int[BRICKCOUNT * BRICKCOUNT2];
	int idx = 0, o = 0;
	for( int z = 0; z < BRICKCOUNT; z++ ) for( int y = 0; y < BRICKCOUNT; y++ ) for( int x = 0; x < BRICKCOUNT; x++, idx++ )
	{
		offs[idx] = o;
		bool hasData = false;
		for( int w = 0; w < BRICKSIZE; w++ ) for( int v = 0; v < BRICKSIZE; v++ ) for( int u = 0; u < BRICKSIZE; u++ )
		{
			int dx = x * BRICKSIZE + u, dy = y * BRICKSIZE + v, dz = z * BRICKSIZE + w;
			brick[o] = vdata[dx + dy * BLOCKSIZE + dz * BLOCKSIZE2];
			if (brick[o++] == 1) hasData = true;
		}
		if (!hasData) offs[idx] = -1;
	}
	// prepare layers
	for( int s = 0; s < 6; s++ )
	{
		grid[s] = new int[GRIDSIZE * GRIDSIZE * SHELLS];
		memset( grid[s], 0, GRIDSIZE * GRIDSIZE * SHELLS * sizeof( int ) );
		for( int l = 0; l < SHELLS; l++ ) for( int y = 0; y < GRIDSIZE; y++ ) for( int x = 0; x < GRIDSIZE; x++ )
			if ((rand() & 3) == 0) grid[s][x + y * GRIDSIZE + l * GRIDSIZE * GRIDSIZE] = 1;
	}
	// prepare job manager
	JobManager::CreateJobManager( THREADS );
}

// tiletracer job definition
class TileTracer : public Job
{
public:
	TileTracer() {}
	TileTracer( int x, int y, Surface* s ) { tx = x, ty = y, screen = s; }
	void Main()
	{
		float dist = 2.1f, aspect = (float)SCRWIDTH / (float)SCRHEIGHT;
		// vec3 O( 0.041f, 0.843f, -0.5f );
		vec3 O( 0.041f, 0.01f, -1.9f );
		vec3 C = O + vec3( 0, 0, 1 ) * dist;
		vec3 a = C + vec3( -1.0f * aspect,  1.0f, 0.0f );
		vec3 b = C + vec3(  1.0f * aspect,  1.0f, 0.0f );
		vec3 c = C + vec3(  1.0f * aspect, -1.0f, 0.0f );
		vec3 d = C + vec3( -1.0f * aspect, -1.0f, 0.0f );
		vec3 p1 = vec3( vec4( a.x, a.y, a.z, 1 ) * M );
		vec3 p2 = vec3( vec4( b.x, b.y, b.z, 1 ) * M );
		vec3 p3 = vec3( vec4( c.x, c.y, c.z, 1 ) * M );
		vec3 p4 = vec3( vec4( d.x, d.y, d.z, 1 ) * M );
		O = vec3( vec4( O.x, O.y, O.z, 1 ) * M );
		vec3 dx = (p2 - p1) * (1.0f / SCRWIDTH);
		vec3 dy = (p4 - p1) * (1.0f / SCRHEIGHT); 
		for( int v = 0; v < TILESIZE; v++ ) for( int u = 0; u < TILESIZE; u++ )
		{
			const int x = tx * TILESIZE + u, y = ty * TILESIZE + v;
			vec3 T = p1 + (float)x * dx + (float)y * dy;
			vec3 D = normalize( T - O );
			screen->Plot( x, y, trace( O, D ) );
		}
	}
	Surface* screen;
	mat4 M;
	vec3 D;
	int tx, ty;
};

TileTracer tt[2048];

// main tick function
float r = 0;
void Game::Tick( float dt )
{
	// ray trace a sphere
	screen->Clear( 0 );
	mat4 M;
	M = mat4::rotatey( -r );
	vec3 D = vec3( vec4( 0, 0, 1, 0 ) * M );
	if ((r += 0.002f) > 2 * PI) r -= 2 * PI; else if (r < 0) r += 2 * PI;
	JobManager* jm = JobManager::GetJobManager();
	int jidx = 0;
	for( int y = 0; y < SCRHEIGHT / TILESIZE; y++ ) for( int x = 0; x < SCRWIDTH / TILESIZE; x++, jidx++ )
	{
		tt[jidx] = TileTracer( x, y, screen );
		tt[jidx].M = M, tt[jidx].D = D;
		jm->AddJob2( &tt[jidx] );
	}
	jm->RunJobs();
	char t[256];
	sprintf( t, "angle: %5.2f", r );
	screen->Print( t, 2, 2, 0xffffff );
	sprintf( t, "x: %i y: %i", mx, my );
	screen->Print( t, 2, 12, 0xffffff );
	unsigned int p = screen->GetBuffer()[mx + my * SCRWIDTH];
	float r = ((p >> 16) & 255) * (1.0f / 128.0f) - 1.0f;
	float g = ((p >>  8) & 255) * (1.0f / 128.0f) - 1.0f;
	float b = ((p >>  0) & 255) * (1.0f / 128.0f) - 1.0f;
	sprintf( t, "N: %4.2f,%4.2f,%4.2f", r, g, b ); 
	screen->Print( t, 2, 22, 0xffffff );
	screen->Line( (float)mx, 0, (float)mx, SCRHEIGHT - 1, 0x880000 );
	screen->Line( 0, (float)my, SCRWIDTH - 1, (float)my, 0x880000 );
}