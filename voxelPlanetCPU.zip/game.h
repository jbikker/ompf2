#pragma once

namespace Tmpl8 {

class Surface;
class Game
{
public:
	void SetTarget( Surface* _Surface ) { screen = _Surface; }
	void Init();
	void Shutdown() { /* implement if you want code to be executed upon app exit */ };
	void HandleInput( float dt ) {};
	void Tick( float dt );
	void MouseUp( int _Button ) { click = false; }
	void MouseDown( int _Button ) { click = true; }
	void MouseMove( int _X, int _Y ) { mx = _X, my = _Y; }
	void KeyUp( int a_Key ) { /* implement if you want to handle keys */ }
	void KeyDown( int a_Key ) { /* implement if you want to handle keys */ }
private:
	Surface* screen;
	int mx, my;
	bool click;
};

}; // namespace Tmpl8