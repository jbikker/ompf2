#pragma once

namespace Tmpl8 {

class BlackHole
{
public:
	BlackHole( float px, float py, float pg );
	float ox, oy, x, y;
	float g;
};

class Particle
{
public:
	Particle() : alive( false ), m( 1.0f ) {};
	float x, y, vx, vy, m;
	bool alive;
	unsigned int c;
};

class Surface;
class Game
{
public:
	void SetTarget( Surface* a_Surface ) { screen = a_Surface; }
	void BuildBackdrop();
	void SpawnParticle( int n );
	void UpdateBlackHoles();
	void UpdateParticles();
	void Init();
	void Tick( float a_DT );
	void KeyDown( int dummy ) {};
	void KeyUp( int dummy ) {};
	void MouseMove( int x, int y ) {};
	void MouseUp( int dummy ) {};
	void MouseDown( int dummy ) {};
private:
	Surface* screen, *m_Backdrop;
	BlackHole** m_Hole;
	Particle** m_Particle;
};

}; // namespace Tmpl8